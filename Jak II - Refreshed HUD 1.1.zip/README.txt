Jak II - Refreshed HUD 1.0

1. Download ZIP file
2. Open the OpenGOAL Launcher
3. Go to Jak II -> Features -> Texture Packs
4. Click 'Add New Pack' and select the ZIP file
5. Click 'Apply Texture Changes'
6. Wait for it to finish decompiling
7. Enjoy!